﻿
// this file is common to both the XPLDirect Xplane plugin and the Arduino interface class


#ifndef XPLDirectCommon_h
#define XPLDirectCommon_h

#define XPL_LEGACY				// Define to remove XPLWizard stuff

#define CFG_FILE				"Resources\\plugins\\XPLDirect\\XPLDirect.cfg"
#define CFG_DESCRIPTIONS_FILE	"Resources\\plugins\\XPLDirect\\XPLDescriptions.cfg"
#define CFG_ABBREVIATIONS_FILE  "Resources\\plugins\\XPLDirect\\abbreviations.txt"

#define XPL_BAUDRATE 115200
#define ARDUINO_WAIT_TIME 2000
#define XPLDIRECT_MILLIS_BETWEEN_FRAMES_DEFAULT 0			// for data sends
#define XPL_RETURN_TIME   .05							// request next visit every .05 seconds or - for cycles
#define XPLDIRECT_PACKETHEADER  '<'							// 
#define XPLDIRECT_PACKETTRAILER '>'							//																
#define XPLDIRECT_MAXDATAREFS_PC 1000
#define XPLDIRECT_MAXCOMMANDS_PC 1000
#define XPLDIRECT_MAXDATAREFS_ARDUINO 8
#define XPLDIRECT_MAXCOMMANDS_ARDUINO 8
#define XPLDEVICES_MAXDEVICES 30
#define XPLDEVICES_MAXWIZARDDEVICES 30
#define XPLCOMPONENTS_MAXCOMPONENTS	500
#define XPLCOMPONENT_MAX_PINS	10
#define XPLCOMPONENT_LED		1
#define XPLCOMPONENT_SWITCH		2

#define XPLMAX_PACKETSIZE 200
#define XPL_TIMEOUT_SECONDS 3

#define XPLERROR                   'E'   // %s         general error
#define XPLRESPONSE_NAME           '0'       
#define XPLRESPONSE_NAMEASWIZARD   '9'
#define XPLRESPONSE_DATAREF        '3'   // %3.3i%s    dataref handle, dataref name 
#define XPLRESPONSE_COMMAND        '4'   // %3.3i%s    command handle, command name
#define XPLRESPONSE_VERSION		   'V'	// %3.3i%u	   customer build ID, version
#define XPLCMD_PRINTDEBUG          '1'
#define XPLCMD_RESET               '2'
#define XPLCMD_SPEAK				'S'
#define XPLCMD_SENDNAME            'a'
#define XPLREQUEST_REGISTERDATAREF 'b'   //  %1.1i%2.2i%5.5i%s    RWMode, array index (0 for non array datarefs), divider to decrease resolution, dataref name
#define XPLREQUEST_REGISTERCOMMAND 'm'  // just the name of the command to register
#define XPLREQUEST_NOREQUESTS      'c'   // nothing to request
#define XPLREQUEST_REFRESH         'd'	//  the plugin will call this once xplane is loaded in order to get fresh updates from arduino handles that write

#define XPLCMD_DATAREFUPDATE       'e'
#define XPLCMD_SENDREQUEST         'f'
#define XPLCMD_DEVICEREADY         'g'
#define XPLCMD_DEVICENOTREADY      'h'
#define XPLCMD_COMMANDSTART         'i'
#define XPLCMD_COMMANDEND           'j'
#define XPLCMD_COMMANDTRIGGER       'k'    // %3.3i%3.3i   command handle, number of triggers
#define XPLCMD_SENDVERSION          'v'     // get current build version from arduino device
#define XPLCMD_SENDBOARDTYPE		'p'		// Only implemented for XPLWizard devices
#define XPLRESPONSE_BOARDTYPE		'q'

#define XPL_EXITING					'x'		// xplane is closing

#define XPLTYPE_XPLDIRECT 1
#define XPLTYPE_XPLWIZARD 2

#define XPL_READ		1
#define XPL_WRITE       2
#define XPL_READWRITE	3

#define XPL_DATATYPE_INT    1
#define XPL_DATATYPE_FLOAT  2
#define XPL_DATATYPE_STRING 3

#define XPL_BOARDTYPE_UNDEFINED  0
//#define XPL_BOARDTYPE_UNO		 1
//#define XPL_BOARDTYPE_MEGA		 2
//#define XPL_BOARDTYPE_NANO		 3
#define MAX_BOARD_TYPES      20
#define MAX_PIN_LABEL	20
#define MAX_PIN_ASSIGNS 10

#define XPL_COMPONENT_LED		1
#define XPL_COMPONENT_SWITCH	2

#endif
