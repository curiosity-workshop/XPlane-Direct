#pragma once
#ifndef MONITORWINDOW_H_INCLUDED
#define MONITORWINDOW_H_INCLUDED



PLUGIN_API int MonitorWindowStart(void);
void CreateTestWidgets(int , int , int , int );

#endif 

