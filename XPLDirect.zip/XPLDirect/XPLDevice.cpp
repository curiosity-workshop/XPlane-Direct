
#define XPLM200

#include "XPLMPlugin.h"
#include "XPLMDataAccess.h"
#include "XPLMDisplay.h"
#include "XPLMGraphics.h"
#include "XPLMMenus.h"

#include "XPWidgets.h"
#include "XPStandardWidgets.h"

#include "XPLMUtilities.h"
#include "XPLMProcessing.h"

#include "XPLMCamera.h"
#include "XPUIGraphics.h"
#include "abbreviations.h"
#include "XPWidgetUtils.h"

#include "DataTransfer.h"
#include "XPLDevice.h"

extern long int packetsSent;
extern long int packetsReceived;
extern FILE* serialLogFile;			// for serial data log
extern FILE* errlog;				// Used for logging problems
extern abbreviations gAbbreviations;

extern int refHandleCounter;
extern int cmdHandleCounter;

extern CommandBinding myCommands[XPLDIRECT_MAXCOMMANDS_PC];
extern DataRefBinding myBindings[XPLDIRECT_MAXDATAREFS_PC];

extern int lastRefReceived;
extern int lastRefSent;
extern int lastCmdAction;

XPLDevice::XPLDevice(int inReference)
{
	bufferPosition = 0;
	readBuffer[0] = '\0';
	lastDebugMessageReceived[0] = '\0';
	RefsLoaded = 0;
	lastSendTime = 0;
	_referenceID = inReference;
	boardType = XPL_BOARDTYPE_UNDEFINED;						// for XPLWizard devices, remains undefined until we query for it.
	_active = 0;
	minTimeBetweenFrames = XPLDIRECT_MILLIS_BETWEEN_FRAMES_DEFAULT;

}

XPLDevice::~XPLDevice()
{
	//if (Port)  delete Port;
		
}

int XPLDevice::isActive(void)
{

	return _active;

}

void XPLDevice::setActive(int flag)
{
	_active = flag;

}


void XPLDevice::processSerial(void)
{
	while (port->readData(&readBuffer[bufferPosition], 1))
	{
		readBuffer[bufferPosition + 1] = '\0';
		//fprintf(errlog, "Buffer currently: %s\r\n", readBuffer);


		if (readBuffer[0] != XPLDIRECT_PACKETHEADER)
		{
			readBuffer[0] = '\0';
			bufferPosition = -1;
		}

		//fprintf(errlog, "comparing %s, %s, %i \r\n", &readBuffer[bufferPosition - strlen(XPLDIRECT_PACKETTRAILER)+1], XPLDIRECT_PACKETTRAILER, strlen(XPLDIRECT_PACKETTRAILER));



		//fprintf(errlog, "%s\r\n", readBuffer);

		if (readBuffer[0] == XPLDIRECT_PACKETHEADER
			&& readBuffer[bufferPosition] == XPLDIRECT_PACKETTRAILER)

		{
			//fprintf(errlog, "found a valid frame...");

			_processPacket();
			readBuffer[0] = '\0';
			bufferPosition = -1;
		}


		if (strlen(readBuffer) >= XPLMAX_PACKETSIZE)
		{
			readBuffer[0] = '\0';    // packet size exceeded / bad packet
			bufferPosition = -1;
		}


		bufferPosition++;
		readBuffer[bufferPosition] = '\0';
	}

}



void XPLDevice::_processPacket(void)
{

	char   writeBuffer[XPLMAX_PACKETSIZE];

	packetsReceived++;


	if (!port) return;

	//	fprintf(errlog, "Processing packet:  %s \r\n", myXPLDevices[port].readBuffer);

	if (serialLogFile) fprintf(serialLogFile, "rx port: %s length: %3.3i buffer:         %s\n", port->portName, (int)strlen(readBuffer), readBuffer);


	readBuffer[bufferPosition] = 0;			// remove the packet trailer

	switch (readBuffer[1])
	{

	case XPLREQUEST_REGISTERDATAREF:
	{
		char arrayReference[4];
		char dividerString[9];

		strncpy(arrayReference, &readBuffer[3], 2);
		strncpy(dividerString, &readBuffer[5], 8);
		strncpy(myBindings[refHandleCounter].xplaneDataRefName, &readBuffer[13], 80);

		//fprintf(errlog, "\n%s\n", dividerString);

		fprintf(errlog, "   Device %s is requesting writemode %c for element %i and a divider of %5.2f for dataref: %s...", deviceName, readBuffer[2], atoi(arrayReference), atof(dividerString), (char *)&readBuffer[13]);

		myBindings[refHandleCounter].xplaneDataRefHandle = XPLMFindDataRef(myBindings[refHandleCounter].xplaneDataRefName);
		if (myBindings[refHandleCounter].xplaneDataRefHandle == NULL)	// if not found, try searching the abbreviations file before giving up
		{
			gAbbreviations.convertString(myBindings[refHandleCounter].xplaneDataRefName);
			myBindings[refHandleCounter].xplaneDataRefHandle = XPLMFindDataRef(myBindings[refHandleCounter].xplaneDataRefName);
		}

		if (myBindings[refHandleCounter].xplaneDataRefHandle != NULL)
		{
			fprintf(errlog, "I found that DataRef!\n");
			
			myBindings[refHandleCounter].bindingActive = 1;
			myBindings[refHandleCounter].deviceIndex = _referenceID;
			myBindings[refHandleCounter].xplaneDataRefArrayOffset = atoi(arrayReference);
			myBindings[refHandleCounter].divider = atof(dividerString);
			myBindings[refHandleCounter].RWMode = readBuffer[2] - '0';
			//fprintf(errlog, "RWMode %c was saved as int %i\r\n", strippedPacket[1], myBindings[refHandleCounter].RWMode);
			myBindings[refHandleCounter].xplaneDataRefTypeID = XPLMGetDataRefTypes(myBindings[refHandleCounter].xplaneDataRefHandle);

			sprintf_s(writeBuffer, XPLMAX_PACKETSIZE, "%3.3i%s", refHandleCounter, (char *)&readBuffer[13]);

			_writePacket(XPLRESPONSE_DATAREF, writeBuffer);



			{
				fprintf(errlog, "      I responded with %3.3i as a handle using this packet:  %s\n", refHandleCounter, writeBuffer);
				if (myBindings[refHandleCounter].xplaneDataRefTypeID & xplmType_Int)        fprintf(errlog, "      This dataref returns that it is of type int\n");
				if (myBindings[refHandleCounter].xplaneDataRefTypeID & xplmType_Float)      fprintf(errlog, "      This dataref returns that it is of type float\n");
				if (myBindings[refHandleCounter].xplaneDataRefTypeID & xplmType_Double)     fprintf(errlog, "      This dataref returns that it is of type double\n");
				if (myBindings[refHandleCounter].xplaneDataRefTypeID & xplmType_FloatArray) fprintf(errlog, "      This dataref returns that it is of type floatArray \n");
				if (myBindings[refHandleCounter].xplaneDataRefTypeID & xplmType_IntArray)   fprintf(errlog, "      This dataref returns that it is of type intArray\n");
				if (myBindings[refHandleCounter].xplaneDataRefTypeID & xplmType_Data)
				{
					fprintf(errlog, "      This dataref returns that it is of type data ***Currently supported only for data sent from xplane (read only)***\n");
					myBindings[refHandleCounter].xplaneCurrentSents = (char*)malloc(XPLMAX_PACKETSIZE - 5);
				}
			}

			refHandleCounter++;
		}
		else

		{
			sprintf_s(writeBuffer, XPLMAX_PACKETSIZE, "-02%s", &readBuffer[13]);
			_writePacket(XPLRESPONSE_DATAREF, writeBuffer);
			myBindings[refHandleCounter].bindingActive = 0;
			fprintf(errlog, "   requested DataRef not found, sorry. \n   I sent back data frame: %s\n", writeBuffer);
			refHandleCounter++;			// to avoid timeout
		}


		break;
	}

	case XPLREQUEST_REGISTERCOMMAND:
	{


		fprintf(errlog, "   Device %s is requesting command: %s...", deviceName, &readBuffer[2]);

		strncpy(myCommands[cmdHandleCounter].xplaneCommandName, &readBuffer[2], 80);
		myCommands[cmdHandleCounter].xplaneCommandHandle = XPLMFindCommand(&readBuffer[2]);
		if (myCommands[cmdHandleCounter].xplaneCommandHandle == NULL)   // if not found, try searching the abbreviations file before giving up
		{
				gAbbreviations.convertString(myCommands[cmdHandleCounter].xplaneCommandName);
				myCommands[cmdHandleCounter].xplaneCommandHandle = XPLMFindCommand(myCommands[cmdHandleCounter].xplaneCommandName);
		}

		

		if (myCommands[cmdHandleCounter].xplaneCommandHandle != NULL)
		{
			fprintf(errlog, "I found that Command!\n");
			
			myCommands[cmdHandleCounter].bindingActive = 1;
			myCommands[cmdHandleCounter].deviceIndex = _referenceID;

			sprintf_s(writeBuffer, XPLMAX_PACKETSIZE, "%3.3i%s", cmdHandleCounter, myCommands[cmdHandleCounter].xplaneCommandName);

			_writePacket(XPLRESPONSE_COMMAND, writeBuffer);

			//if (!myXPLDevices[port].Port->WriteData(writeBuffer, strlen(writeBuffer)))
			//	fprintf(errlog, "      Problem occurred sending handle to the device, sorry.\n");
			//else
			{
				fprintf(errlog, "      I responded with %3.3i as a handle using this packet:  %s\n", cmdHandleCounter, writeBuffer);
			}

			cmdHandleCounter++;
		}
		else

		{
			sprintf_s(writeBuffer, XPLMAX_PACKETSIZE, "-02%s", &readBuffer[2]);
			_writePacket(XPLRESPONSE_COMMAND, writeBuffer);
			myCommands[cmdHandleCounter].bindingActive = 0;
			fprintf(errlog, "   requested Command not found, sorry. \n   I sent back data frame: %s\n", writeBuffer);
			cmdHandleCounter++;
		}


		break;
	}

	case XPLCMD_DATAREFUPDATE:
	{

		float tempFloat;
		int tempInt;

		char* stopstring;
		char bindingNumberStr[4];
		int  bindingNumber;

		//	fprintf(errlog, "Device is sending dataRef update with packet: %s \r\n", strippedPacket);

		bindingNumberStr[3] = 0;
		bindingNumber = atoi(strncpy(bindingNumberStr, &readBuffer[2], 3));

		if (bindingNumber < 0 && bindingNumber > refHandleCounter) break;

		lastRefReceived = bindingNumber;			// for the status window

		if (myBindings[bindingNumber].xplaneDataRefTypeID & xplmType_Int)
		{
			//fprintf(errlog, "update data is int: %i\r\n", strtol(&myXPLDevices[port].readBuffer[5], &stopstring, 10) );
			XPLMSetDatai(myBindings[bindingNumber].xplaneDataRefHandle, strtol(&readBuffer[5], &stopstring, 10));
			myBindings[bindingNumber].xplaneCurrentReceivedl = strtol(&readBuffer[5], &stopstring, 10);
			myBindings[bindingNumber].xplaneCurrentSentl = myBindings[bindingNumber].xplaneCurrentReceivedl;
		}

		if (myBindings[bindingNumber].xplaneDataRefTypeID & xplmType_Float)
		{
			//	fprintf(errlog, "update data is float: %f\r\n", strtof(&strippedPacket[4], &stopstring) );
			XPLMSetDataf(myBindings[bindingNumber].xplaneDataRefHandle, strtof(&readBuffer[5], &stopstring));
			myBindings[bindingNumber].xplaneCurrentReceivedf = strtof(&readBuffer[5], &stopstring);
			myBindings[bindingNumber].xplaneCurrentSentf = myBindings[bindingNumber].xplaneCurrentReceivedf;
		}

		if (myBindings[bindingNumber].xplaneDataRefTypeID & xplmType_Double)
		{
			XPLMSetDatad(myBindings[bindingNumber].xplaneDataRefHandle, strtod(&readBuffer[5], &stopstring));
			myBindings[bindingNumber].xplaneCurrentReceivedD = strtod(&readBuffer[5], &stopstring);
			myBindings[bindingNumber].xplaneCurrentSentD = myBindings[bindingNumber].xplaneCurrentReceivedD;
		}

		if (myBindings[bindingNumber].xplaneDataRefTypeID & xplmType_IntArray)
		{
			tempInt = (int)strtol(&readBuffer[5], &stopstring, 10);
			XPLMSetDatavi(myBindings[bindingNumber].xplaneDataRefHandle, &tempInt, myBindings[bindingNumber].xplaneDataRefArrayOffset, 1);
			myBindings[bindingNumber].xplaneCurrentReceivedl = tempInt;
			myBindings[bindingNumber].xplaneCurrentSentl = tempInt;
		}

		if (myBindings[bindingNumber].xplaneDataRefTypeID & xplmType_FloatArray)						// process for datarefs of type float (array)
		{
			tempFloat = strtof(&readBuffer[5], &stopstring);
			XPLMSetDatavf(myBindings[bindingNumber].xplaneDataRefHandle, &tempFloat, myBindings[bindingNumber].xplaneDataRefArrayOffset, 1);
			myBindings[bindingNumber].xplaneCurrentReceivedf = tempFloat;
			myBindings[bindingNumber].xplaneCurrentSentf = tempFloat;
		}


		break;
	}

	case XPLCMD_COMMANDSTART:
	case XPLCMD_COMMANDEND:
	case XPLCMD_COMMANDTRIGGER:
	{

		char commandNumberStr[4];
		int  commandNumber;  
		int  triggerCount;
		char* stopstring;

		commandNumberStr[3] = 0;
		commandNumber = atoi(strncpy(commandNumberStr, &readBuffer[2], 3));

	//	fprintf(errlog, "Command received for myCommands[%i].  cmdHandleCounter = %i. readBuffer: %s\n", commandNumber, cmdHandleCounter, readBuffer);


		if (commandNumber < 0 || commandNumber >= cmdHandleCounter) break;

		lastCmdAction = commandNumber;

		if (readBuffer[1] == XPLCMD_COMMANDTRIGGER)
		{

			triggerCount = (int)strtol(&readBuffer[5], &stopstring, 10);
		//	fprintf(errlog, "Device is sending Command %i %i times \n", commandNumber, triggerCount);
			myCommands[commandNumber].accumulator += triggerCount-1;

			XPLMCommandOnce(myCommands[commandNumber].xplaneCommandHandle);

				


			break;
		}

		if (readBuffer[1] == XPLCMD_COMMANDSTART)
		{
		//	fprintf(errlog, "Device is sending Command Start to derived commandNumber: %i\n", commandNumber);
			XPLMCommandBegin(myCommands[commandNumber].xplaneCommandHandle);
		}

		if (readBuffer[1] == XPLCMD_COMMANDEND)
		{
		//	fprintf(errlog, "Device is sending Command End to derived commandNumber: %i\n", commandNumber);
			//fprintf(errlog, "Device is sending Command End with packet: %s \n", strippedPacket);
			XPLMCommandEnd(myCommands[commandNumber].xplaneCommandHandle);
		}

		break;
	}


	case XPLCMD_PRINTDEBUG:
	{
		fprintf(errlog, "Device %s sent debug message: %s\n", deviceName, &readBuffer[2]);
		strcpy(lastDebugMessageReceived, &readBuffer[2]);

		break;
	}

	case XPLCMD_SPEAK:
	{
		XPLMSpeakString(&readBuffer[2]);
		break;
	}

	case XPLRESPONSE_NAME:
	{
		//fprintf(errlog, "Received name response packet %s\r\n", strippedPacket);
		snprintf(deviceName, 80, "%s", &readBuffer[2]);
		setActive(1);
		deviceType = XPLTYPE_XPLDIRECT;			// is a XPLDirect device
		break;
	}

	case XPLRESPONSE_NAMEASWIZARD:
	{
		//fprintf(errlog, "Received name response packet %s\r\n", strippedPacket);
		snprintf(deviceName, 80, "%s", &readBuffer[2]);
		setActive(1);
		deviceType = XPLTYPE_XPLWIZARD;			// is a XPLWizard device
		break;
	}

	
	case XPLREQUEST_NOREQUESTS:
	{
		RefsLoaded = 1;
		fprintf(errlog, "   Device %s says it has no more dataRefs or commands to register!\n\n", deviceName);
		break;
	}

	case XPLCMD_RESET:
	{
		reloadDevices();
		break;
	}

	default:
	{
		fprintf(errlog, "invalid command received\n");
		break;
	}

	}
}



int XPLDevice::_writePacket(char cmd, char* packet)
{
	//return 0;
	char writeBuffer[XPLMAX_PACKETSIZE];
	snprintf(writeBuffer, XPLMAX_PACKETSIZE, "%c%c%s%c", XPLDIRECT_PACKETHEADER, cmd, packet, XPLDIRECT_PACKETTRAILER);


	if (serialLogFile) fprintf(serialLogFile, "tx port: %s length: %3.3zi packet: %s\n", port->portName, strlen(writeBuffer), writeBuffer);



	if (!port->writeData(writeBuffer, strlen(writeBuffer)))
	{
		fprintf(errlog, "Problem occurred during write: %s.\n", writeBuffer);
		return 0;
	}

	packetsSent++;

	return 1;
}


int XPLDevice::_writePacketN(char cmd, char* packet, int packetSize)
{
	//return 0;
	char writeBuffer[XPLMAX_PACKETSIZE];
	snprintf(writeBuffer, XPLMAX_PACKETSIZE, "%c%c", XPLDIRECT_PACKETHEADER, cmd);
	memcpy((void*)&writeBuffer[2], packet, packetSize);
	writeBuffer[packetSize + 2] = XPLDIRECT_PACKETTRAILER;
	writeBuffer[packetSize + 3] = 0;							// terminate with null

	if (serialLogFile)
	{
		fprintf(serialLogFile, "tx port: %s length: %3.3i packet: ",port->portName, packetSize + 3);
		for (int i = 0; i < packetSize + 3; i++)
		{
			if (isprint(writeBuffer[i]))	fprintf(serialLogFile, "%c", writeBuffer[i]);
			else fprintf(serialLogFile, "~");
		}
		fprintf(serialLogFile, "\n");

	}

	if (!port->writeData(writeBuffer, packetSize + 6))
	{
		fprintf(errlog, "Problem occurred during write: %s.\n", writeBuffer);
		return 0;
	}

	packetsSent++;

	return 1;
}
