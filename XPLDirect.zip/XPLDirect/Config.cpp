
#include <string.h>
//#include "XPLDirectCommon.h"

#include "Config.h"

Config::Config(char *inFileName)
{

    strncpy(_cfgFileName, inFileName, 512);
    _cfgFileName[511] = 0;
    
    FILE* cfgFile;
    _validConfig = false;
    
   
    if (cfgFile = fopen(_cfgFileName, "r"))
        fclose(cfgFile);
    else
    {
        fprintf(errlog, "***Configuration file %s doesn't exist, please replace...\n", _cfgFileName);
        return;
       // createNewConfigFile();
    }
    
    fprintf(errlog, "Opening configuration file %s... ", _cfgFileName);
    
	//config_setting_t* root, * setting, * group, * array;
	config_init(&_cfg);

    if (!config_read_file(&_cfg, _cfgFileName))
    {
        fprintf(errlog, "Error: %s  Line:%i\r\n", config_error_text(&_cfg), config_error_line(&_cfg));
        config_destroy(&_cfg);
           
    }
    else                                      
        fprintf(errlog, "Success.\n");
  
    _validConfig = true;
 
}

Config::~Config()
{
    if (_validConfig) return;

    config_write_file(&_cfg, _cfgFileName);
   
	config_destroy(&_cfg);
}


// commit changes to the configuration file
void Config::saveFile(void)
{
    if (!config_write_file(&_cfg, _cfgFileName))
    {
        fprintf(errlog, "Config::saveFile Error: %s  Line:%i\r\n", config_error_text(&_cfg), config_error_line(&_cfg));
        return;
    }
    else
    {
       // fprintf(errlog, "Config::saveFile: Success updating configuration file.\n");
       

    }
}


// getSerialLogFlag
int Config::getSerialLogFlag(void)
{
    int flag = 0;
 
    if (!_validConfig) return 0;

    if (config_lookup_int(&_cfg, "XPLPlugin.logSerialData", &flag) == CONFIG_TRUE)
        fprintf(errlog, "Config module found XPLPlugin.logSerialData value %i\r\n", flag);
    else 
        fprintf(errlog, "*** Config module returned CONFIG_FALSE looking up value XPLPlugin.logSerialData \r\n");

    return flag;
}

void Config::setSerialLogFlag(int flag)
{
    if (!_validConfig) return;

    config_setting_t* flagSetting = config_lookup(&_cfg, "XPLPlugin.logSerialData");

    if (flagSetting == NULL)
    {
        fprintf(errlog, "*** Config module unable to locate path XPLPlugin.logSerialData during write\r\n");
        return;
    }

    if (config_setting_set_int(flagSetting, flag) == CONFIG_TRUE)
        fprintf(errlog, "Config module set XPLPlugin.logSerialData to value %i\r\n", flag);
    else
        fprintf(errlog, "***Config module returned error setting XPLPlugin.logSerialData to value %i\r\n", flag);
}





/*

Stuff related to components

*/

int Config::getComponentCount(void)
{


    config_setting_t* components;

    if (!_validConfig) return 0;

    components = config_lookup(&_cfg, "XPLPlugin.XPLWizard.components");
    if (!components)
    {
        fprintf(errlog, "***getComponentCount:  I was unable to locate path: XPLPlugin.XPLWizard.components\n");
        return 0;
    }


    return config_setting_length(components);

}



int Config::getComponentInfo(int element, int* type, const char** name, const char ** board, int* pinCount, int *linkCount)
{
   
    config_setting_t* components;
    config_setting_t* componentElement;
    config_setting_t* pins;
    config_setting_t* links;

    components = config_lookup(&_cfg, "XPLPlugin.XPLWizard.components");
    if (!components)
    {
        fprintf(errlog, "***getComponentInfo:  I was unable to locate path: XPLPlugin.XPLWizard.components\n");
        return false;
    }
    
    componentElement = config_setting_get_elem(components, element);
    if (!componentElement)
    {
        fprintf(errlog, "***getComponentInfo:  I was unable to locate element %i of path: XPLPlugin.XPLWizard.components\n", element);
        return false;
    }


    if (name    != NULL)        config_setting_lookup_string(componentElement, "name", name);
    if (type != NULL)           config_setting_lookup_int(componentElement, "type", type);
    if (board   != NULL)        config_setting_lookup_string(componentElement, "board", board);
    

    pins = config_setting_lookup(componentElement, "pins");
    if (!pins) *pinCount = 0;
    else
    {
        *pinCount = config_setting_length(pins);
    }

    links = config_setting_lookup(componentElement, "links");
    if (!links) *linkCount = 0;
    else
    {
        *linkCount = config_setting_length(links);
    }

     return true;
}

// setComponentInfo
void Config::setComponentInfo(int element, int* type, const char* name, const char* board, const char* dataref, int arrayElement)
{

    config_setting_t* components;
    config_setting_t* componentElement;
    config_setting_t* stringLookup;

    components = config_lookup(&_cfg, "XPLPlugin.XPLWizard.components");
    if (!components)
    {
        fprintf(errlog, "***setComponentInfo:  I was unable to locate path: XPLPlugin.XPLWizard.components\n");
        return;
    }

    componentElement = config_setting_get_elem(components, element);
    if (!componentElement)
    {
        fprintf(errlog, "***setComponentInfo:  I was unable to locate element %i of path: XPLPlugin.XPLWizard.components\n", element);
        return;
    }
   
    stringLookup = config_setting_lookup(componentElement, "name");
    if (stringLookup && name != NULL) config_setting_set_string(stringLookup, name);
    else fprintf(errlog, "***setComponentInfo: unable to locate component element: name\n");
    
    stringLookup = config_setting_lookup(componentElement, "dataRef");
    if (stringLookup && dataref != NULL) config_setting_set_string(stringLookup, dataref);
    else fprintf(errlog, "***setComponentInfo: unable to locate component element: dataRef\n");

    //if (name != NULL)        config_setting_lookup_string(componentElement, "name", name);
    //if (type)                   config_setting_lookup_int(componentElement, "type", type);
    //if (board != NULL)        config_setting_lookup_string(componentElement, "board", board);
    //if (dataref != NULL)        config_setting_lookup_string(componentElement, "dataRef", dataref);
    //if (arrayElement != NULL)   config_setting_lookup_int(componentElement, "arrayElement", arrayElement);


  //  pins = config_setting_lookup(componentElement, "pins");
  //  if (!pins) *pinCount = 0;
  //  else
  //  {
  //      *pinCount = config_setting_length(pins);
  //  }
    saveFile();
    return;
}

int Config::getComponentLinkInfo(int componentIndex, int linkIndex, char* inName, const char** outData)
{
    config_setting_t* components;
    config_setting_t* componentElement;
    config_setting_t* linkElement;
    config_setting_t* links;
    config_setting_t* request;

    char path[] = "XPLPlugin.XPLWizard.components";

    components = config_lookup(&_cfg, path);
    if (!components)
    {
        fprintf(errlog, "***getComponentLinkInfo:  I was unable to locate path: %s\n", path);
        return false;
    }

    componentElement = config_setting_get_elem(components, componentIndex);
    if (!componentElement)
    {
        fprintf(errlog, "***getComponentLinkInfo:  I was unable to locate element %i of path: %s\n", componentIndex, path);
        return false;
    }

    links = config_setting_lookup(componentElement, "links");
    if (!links)
    {
        fprintf(errlog, "***getComponentLinkInfo:  I was unable to locate 'links' in element %i of path: %s\n", componentIndex, path);
        return false;
    }
    else
    {

        linkElement = config_setting_get_elem(links, linkIndex);
        if (!linkElement)
        {
            fprintf(errlog, "***getComponentLinkInfo:  I was unable to locate link element %i in path: %s\n", componentIndex, path);
            return false;
        }

      
    }
    
    request = config_setting_lookup(linkElement, inName);
    if (!request)
    {
        fprintf(errlog, "***getComponentLinkInfo:  I was unable to locate '%s' in element %i of path: %s\n", inName, componentIndex, path);
        return false;
    }
    else
    {
              

        *outData = config_setting_get_string(request);
    }
    return true;
   

}

int Config::getComponentLinkInfo(int componentIndex, int linkIndex, char* inName, int * outData)
{
    config_setting_t* components;
    config_setting_t* componentElement;
    config_setting_t* linkElement;
    config_setting_t* links;
    config_setting_t* request;

    char path[] = "XPLPlugin.XPLWizard.components";

    components = config_lookup(&_cfg, path);
    if (!components)
    {
        fprintf(errlog, "***getComponentLinkInfo:  I was unable to locate path: %s\n", path);
        return false;
    }

    componentElement = config_setting_get_elem(components, componentIndex);
    if (!componentElement)
    {
        fprintf(errlog, "***getComponentLinkInfo:  I was unable to locate element %i of path: %s\n", componentIndex, path);
        return false;
    }

    links = config_setting_lookup(componentElement, "links");
    if (!links)
    {
        fprintf(errlog, "***getComponentLinkInfo:  I was unable to locate 'links' in element %i of path: %s\n", componentIndex, path);
        return false;
    }
    else
    {

        linkElement = config_setting_get_elem(links, linkIndex);
        if (!linkElement)
        {
            fprintf(errlog, "***getComponentLinkInfo:  I was unable to locate link element %i in path: %s\n", componentIndex, path);
            return false;
        }


    }

    request = config_setting_lookup(linkElement, inName);
    if (!request)
    {
        fprintf(errlog, "***getComponentLinkInfo:  I was unable to locate '%s' in element %i of path: %s\n", inName, componentIndex, path);
        return false;
    }
    else
    {


        *outData = config_setting_get_int(request);
    }
    return true;


}

int Config::getComponentPinInfo(int componentIndex, int pinIndex, const char** pinName)
{

    config_setting_t* components;
    config_setting_t* componentElement;
    config_setting_t* pinElement;
    config_setting_t* pins;

    char path[] = "XPLPlugin.XPLWizard.components";

    components = config_lookup(&_cfg, path);
    if (!components)
    {
        fprintf(errlog, "***getComponentPinInfo:  I was unable to locate path: %s\n", path);
        return false;
    }

    componentElement = config_setting_get_elem(components, componentIndex);
    if (!componentElement)
    {
        fprintf(errlog, "***getComponentPinInfo:  I was unable to locate element %i of path: %s\n", componentIndex, path);
        return false;
    }
   
    pins = config_setting_lookup(componentElement, "pins");
    if (!pins)
    {
        fprintf(errlog, "***getComponentPinInfo:  I was unable to locate pins in element %i of path: %s\n", componentIndex, path);
        return false;
    }
    else
    {

        pinElement = config_setting_get_elem(pins, pinIndex);
        if (!pinElement)
        {
            fprintf(errlog, "***getComponentPinInfo:  I was unable to locate pin element %i in path: %s\n", componentIndex, path);
            return false;
        }

        *pinName = config_setting_get_string(pinElement);
    }
    
   return true;
}

