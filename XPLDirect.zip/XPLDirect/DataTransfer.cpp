#define XPLM200

#include "SerialClass.h"

#include "XPLDirectCommon.h"

#include "XPLMPlugin.h"
#include "XPLMDataAccess.h"
#include "XPLMDisplay.h"
#include "XPLMGraphics.h"
#include "XPLMMenus.h"

#include "XPWidgets.h"
#include "XPStandardWidgets.h"

#include "XPLMUtilities.h"
#include "XPLMProcessing.h"

#include "XPLMCamera.h"
#include "XPUIGraphics.h"
#include "XPWidgetUtils.h"

#include "XPLDirectCommon.h"
#include "XPLDirect.h"
#include "XPLDevice.h"

#include "DataTransfer.h"

#include <ctime>



int refHandleCounter = 0;
int cmdHandleCounter = 0;


long int packetsSent;
long int packetsReceived;

int validPorts = 0;

extern FILE* errlog;
extern FILE* serialLogFile;
extern float elapsedTime;
extern int lastRefSent;

CommandBinding myCommands[XPLDIRECT_MAXCOMMANDS_PC];
DataRefBinding myBindings[XPLDIRECT_MAXDATAREFS_PC];
XPLDevice* myXPLDevices[XPLDEVICES_MAXDEVICES];

/**************************************************************************************/
/* disengage -- unregister all datarefs and close all com ports                       */
/**************************************************************************************/
void disengageDevices(void)
{
		
	sendExitMessage();
	

	for (int i = 0; i < validPorts; i++)
	{
		if (myXPLDevices[i])
		{
			
			myXPLDevices[i]->port->shutDown();
			delete myXPLDevices[i]->port;
			
			delete myXPLDevices[i];
			myXPLDevices[i] = NULL;
		}
	}

	validPorts = 0;

	for (int i = 0; i < refHandleCounter; i++)
	{
		myBindings[i].deviceIndex = -1;
		myBindings[i].bindingActive = 0;
		myBindings[i].Handle = -1;
		myBindings[i].RWMode = 0;
		XPLMUnregisterDataAccessor(myBindings[i].xplaneDataRefHandle);  // deregister with xplane
		myBindings[i].xplaneDataRefTypeID = 0;
		myBindings[i].xplaneDataRefName[0] = NULL;
		if (myBindings[i].xplaneCurrentSents != NULL)
		{
			free(myBindings[i].xplaneCurrentSents);
			myBindings[i].xplaneCurrentSents = NULL;
		}

	}

	refHandleCounter = 0;

	for (int i = 0; i < cmdHandleCounter; i++)
	{
		myCommands[i].deviceIndex = -1;
		myCommands[i].bindingActive = 0;
		myCommands[i].Handle = -1;
		myCommands[i].xplaneCommandHandle = NULL;
		myCommands[i].xplaneCommandName[0] = NULL;

	}

	cmdHandleCounter = 0;


}

/*
*   Searches com ports for devices, then queries for datarefs and commands.
*/
void engageDevices(void)
{

	//if (validPorts == 0) getComPorts();
	

	findDevices();
	activateDevices();
	_updateDataRefs(1);				// 1 represents to force updates to the devices
	sendRefreshRequest();

}

/**************************************************************************************/
/* _updateDataRefs -- get current dataref values for all registered datarefs          */
/**************************************************************************************/
void _updateDataRefs(int forceUpdate)
{

	long int newVall;
	float newValf;
	double newValD;

	char   writeBuffer[XPLMAX_PACKETSIZE];
	char   stringBuffer[XPLMAX_PACKETSIZE - 5];



	for (int i = 0; i < refHandleCounter; i++)
	{
		if (myBindings[i].bindingActive)
		{
			
		//	if (elapsedTime - myXPLDevices[myBindings[i].deviceIndex].lastSendTime < myXPLDevices[myBindings[i].deviceIndex].minTimeBetweenFrames/1000 && !forceUpdate)
	//			break;


			switch (myBindings[i].RWMode)
			{

			case XPL_READ:
			case XPL_READWRITE:
			{
				if (myBindings[i].xplaneDataRefTypeID & xplmType_Int)						// process for datarefs of type int
				{

					newVall = (long int)XPLMGetDatai(myBindings[i].xplaneDataRefHandle);

					//   fprintf(errlog, "updating dataRef %s with value %i...\r\n  ", myBindings[i].xplaneDataRefName, newVall);

					if (newVall != myBindings[i].xplaneCurrentSentl || forceUpdate)
					{
						lastRefSent = i;
						myBindings[i].xplaneCurrentSentl = newVall;
						sprintf_s(writeBuffer, XPLMAX_PACKETSIZE, "%3.3i%ld", i, newVall);
						myXPLDevices[myBindings[i].deviceIndex]->_writePacket(XPLCMD_DATAREFUPDATE, writeBuffer);
						myXPLDevices[myBindings[i].deviceIndex]->lastSendTime = elapsedTime;

						//   fprintf(errlog, "using packet: %s\r\n", writeBuffer);

					}

					break;
				}

				if (myBindings[i].xplaneDataRefTypeID & xplmType_IntArray)						// process for datarefs of type int Array
				{

					XPLMGetDatavi(myBindings[i].xplaneDataRefHandle, (int*)&newVall, myBindings[i].xplaneDataRefArrayOffset, 1);

					// fprintf(errlog, "updating dataRef %s with value %i...\r\n  ", myBindings[i].xplaneDataRefName, newVall);

					if (newVall != myBindings[i].xplaneCurrentSentl || forceUpdate)
					{
						lastRefSent = i;
						myBindings[i].xplaneCurrentSentl = newVall;
						sprintf_s(writeBuffer, XPLMAX_PACKETSIZE, "%3.3i%ld", i, newVall);
						myXPLDevices[myBindings[i].deviceIndex]->_writePacket(XPLCMD_DATAREFUPDATE, writeBuffer);
						myXPLDevices[myBindings[i].deviceIndex]->lastSendTime = elapsedTime;

						//   fprintf(errlog, "using packet: %s\r\n", writeBuffer);

					}

					break;
				}

				if (myBindings[i].xplaneDataRefTypeID & xplmType_Float)						// process for datarefs of type float
				{

					newValf = (float)XPLMGetDataf(myBindings[i].xplaneDataRefHandle);

					// fprintf(errlog, "updating dataRef %s with value %f...\r\n  ", myBindings[i].xplaneDataRefName, newValf);
					if (myBindings[i].divider)  newValf = ((int)(newValf / myBindings[i].divider) * myBindings[i].divider);

					if (newValf != myBindings[i].xplaneCurrentSentf || forceUpdate)
					{
						lastRefSent = i;
						myBindings[i].xplaneCurrentSentf = newValf;
						sprintf_s(writeBuffer, XPLMAX_PACKETSIZE, "%3.3i%f", i, newValf);
						myXPLDevices[myBindings[i].deviceIndex]->_writePacket(XPLCMD_DATAREFUPDATE, writeBuffer);
						myXPLDevices[myBindings[i].deviceIndex]->lastSendTime = elapsedTime;

						//   	   fprintf(errlog, "using packet: %s\r\n", writeBuffer);

					}
					break;
				}


				if (myBindings[i].xplaneDataRefTypeID & xplmType_FloatArray)						// process for datarefs of type float (array)
				{

					XPLMGetDatavf(myBindings[i].xplaneDataRefHandle, (float*)&newValf, myBindings[i].xplaneDataRefArrayOffset, 1);

					//fprintf(errlog, "updating dataRef %s with value %f from dataref offset %i\r\n  ", myBindings[i].xplaneDataRefName, newValf, myBindings[i].xplaneDataRefArrayOffset+1);
					if (myBindings[i].divider)  newValf = ((int)(newValf / myBindings[i].divider) * myBindings[i].divider);

					if (newValf != myBindings[i].xplaneCurrentSentf || forceUpdate)
					{
						lastRefSent = i;
						myBindings[i].xplaneCurrentSentf = newValf;
						sprintf_s(writeBuffer, XPLMAX_PACKETSIZE, "%3.3i%f", i, newValf);
						myXPLDevices[myBindings[i].deviceIndex]->_writePacket(XPLCMD_DATAREFUPDATE, writeBuffer);
						myXPLDevices[myBindings[i].deviceIndex]->lastSendTime = elapsedTime;

						//  fprintf(errlog, "using packet: %s\r\n", writeBuffer);

					}
					break;
				}

				if (myBindings[i].xplaneDataRefTypeID & xplmType_Double)						// process for datarefs of type double
				{

					newValD = (double)XPLMGetDatad(myBindings[i].xplaneDataRefHandle);

					// fprintf(errlog, "updating dataRef %s with value %f...\r\n  ", myBindings[i].xplaneDataRefName, newValf);
					if (myBindings[i].divider)  newValD = ((int)(newValD / myBindings[i].divider) * myBindings[i].divider);

					if (newValD != myBindings[i].xplaneCurrentSentD || forceUpdate)
					{
						lastRefSent = i;
						myBindings[i].xplaneCurrentSentD = newValD;
						sprintf_s(writeBuffer, XPLMAX_PACKETSIZE, "%3.3i%f", i, newValD);
						myXPLDevices[myBindings[i].deviceIndex]->_writePacket(XPLCMD_DATAREFUPDATE, writeBuffer);
						myXPLDevices[myBindings[i].deviceIndex]->lastSendTime = elapsedTime;

						//   	   fprintf(errlog, "using packet: %s\r\n", writeBuffer);

					}
					break;
				}

				if (myBindings[i].xplaneDataRefTypeID & xplmType_Data)						// process for datarefs of type Data (strings)
				{

					newVall = (long int)XPLMGetDatab(myBindings[i].xplaneDataRefHandle, stringBuffer, 0, XPLMAX_PACKETSIZE - 5);
					//stringBuffer[newVall] = 0;		// null terminate
					//   fprintf(errlog, "updating dataRef %s with value %i...\r\n  ", myBindings[i].xplaneDataRefName, newVall);

					if (memcmp(myBindings[i].xplaneCurrentSents, stringBuffer, newVall) || forceUpdate)
					{
						lastRefSent = i;
						memcpy(myBindings[i].xplaneCurrentSents, stringBuffer, newVall);
						sprintf(writeBuffer, "%3.3i", i);
						for (int j = 0; j < newVall; j++)
							if (stringBuffer[j] == XPLDIRECT_PACKETTRAILER) stringBuffer[j] = 7;		// deal with possibility of packet trailer in string

						memcpy(&writeBuffer[3], stringBuffer, newVall);
						myXPLDevices[myBindings[i].deviceIndex]->_writePacketN(XPLCMD_DATAREFUPDATE, writeBuffer, newVall + 3);
						myXPLDevices[myBindings[i].deviceIndex]->lastSendTime = elapsedTime;

					//	fprintf(errlog, "Updating dataref %s with packet: %s length: %i\r\n", myBindings[i].xplaneDataRefName, writeBuffer, newVall);

					}

					break;
				}
				break;

			}
			}
		}

	}


}

/*
	_updateCommands -- make sure commands are all updated.
 */
void _updateCommands(void)
{
	
	
	for (int i = 0; i < cmdHandleCounter; i++)
	{
		if (myCommands[i].bindingActive && myCommands[i].accumulator > 0)
		{
			
			XPLMCommandOnce(myCommands[i].xplaneCommandHandle);
			myCommands[i].accumulator--;
			
			
		}

	}


}

/**************************************************************************************/
/* activateDevices -- request dataref bindings from all active devices                */
/**************************************************************************************/
void activateDevices(void)
{
	int timeout = 0;
	time_t startTime;
	int refHandleCounterOLD;
	int cmdHandleCounterOLD;

	XPLMDebugString("XPLDirect:  Activating Devices... ");

	for (int i = 0; i < XPLDEVICES_MAXDEVICES; i++)
	{
		if (!myXPLDevices[i]) break;

		timeout = 0;
		if (myXPLDevices[i]->deviceType == XPLTYPE_XPLDIRECT)
		{
			while (myXPLDevices[i] && !timeout && !myXPLDevices[i]->RefsLoaded)
			{
				refHandleCounterOLD = refHandleCounter;							// this will change with a successful dataRef registration
				cmdHandleCounterOLD = cmdHandleCounter;							// this will change with a successful command registration
				//Sleep(100);
				fprintf(errlog, "Requesting dataRef or Command registration from device: %s\n", myXPLDevices[i]->deviceName);
				myXPLDevices[i]->_writePacket(XPLCMD_SENDREQUEST, "");
				startTime = time(NULL);
				while (difftime(time(NULL), startTime) < XPL_TIMEOUT_SECONDS
					&& !myXPLDevices[i]->RefsLoaded && refHandleCounter == refHandleCounterOLD && cmdHandleCounter == cmdHandleCounterOLD)
					_processSerial();
				if (difftime(time(NULL), startTime) >= XPL_TIMEOUT_SECONDS)
				{
					timeout = 1;
					fprintf(errlog, "   Hmmm, timed out waiting for response from device: %s\n", myXPLDevices[i]->deviceName);
					fprintf(errlog, "   Its read buffer at the time was: %s\n", myXPLDevices[i]->readBuffer);
					fprintf(errlog, "     Start time: %ld End Time %ld\n", (long)startTime, (long)time(NULL));
					strcpy(myXPLDevices[i]->lastDebugMessageReceived, "Timed out during dataRef or Command Registration, dataref not found?");
				}

			}
		}

		if (myXPLDevices[i]->deviceType == XPLTYPE_XPLWIZARD)
		{
			while (myXPLDevices[i] && !timeout && myXPLDevices[i]->boardType == 0)
			{

				fprintf(errlog, "Requesting device type from XPLWizard device: %s\n", myXPLDevices[i]->deviceName);
				myXPLDevices[i]->_writePacket(XPLCMD_SENDBOARDTYPE, "");
				startTime = time(NULL);
				while (difftime(time(NULL), startTime) < XPL_TIMEOUT_SECONDS
					&& !myXPLDevices[i]->boardType)
					_processSerial();
				if (difftime(time(NULL), startTime) >= XPL_TIMEOUT_SECONDS)
				{
					timeout = 1;
					fprintf(errlog, "   Hmmm, timed out waiting for response from XPLWizard device: %s\n", myXPLDevices[i]->deviceName);
					fprintf(errlog, "   Its read buffer at the time was: %s\n", myXPLDevices[i]->readBuffer);
					fprintf(errlog, "     Start time: %ld End Time %ld\n", (long)startTime, (long)time(NULL));
					strcpy(myXPLDevices[i]->lastDebugMessageReceived, "Timed out during request for board type. ");
				}

			}
		}
		//	fprintf(errlog, "\r\n");

	}
	XPLMDebugString("  Done Activating Devices\n");
	fprintf(errlog, "activateDevices:  Completed.\n\n");

}

/*
   findDevices -- Scan for XPLDirect devices and fills array with active devices
*/

bool findDevices(void)
{
	//	long t1 = System.currentTimeMillis();
	
	serialClass* port;

		//DWORD dwRet;

		//int bytesRead;
	validPorts = 0;
	time_t startTime;
	XPLMDebugString("XPLDirect:  Searching Com Ports... ");
	for (UINT i = 1; i < 256; i++)
	{
		port = new serialClass;

		if (port->begin(i) == i)
		{
	//		bSuccess = true;
			fprintf(errlog, "\nFound valid port %s.  Attemping poll for XPLDirect device... ", port->portName);
			//Sleep(100);
			myXPLDevices[validPorts] = new XPLDevice(validPorts);
			myXPLDevices[validPorts]->port = port;

			if (myXPLDevices[validPorts]->_writePacket(XPLCMD_SENDNAME, ""))
				fprintf(errlog, "Valid write operation, seems OK\n");


			startTime = time(NULL);

			//fprintf(errlog, "startTime: %d\r\n", startTime);
			while (difftime(time(NULL), startTime) < XPL_TIMEOUT_SECONDS && !myXPLDevices[validPorts]->isActive())	_processSerial();

			if (!myXPLDevices[validPorts]->isActive())
			{
				fprintf(errlog, "No response after %i seconds\n", XPL_TIMEOUT_SECONDS);
				//XPLMDebugString(".");
				port->shutDown();
				delete myXPLDevices[validPorts];
				myXPLDevices[validPorts] = NULL;
				delete port;
				//myXPLDevices[validPorts]->comPortName[0] = 0;
			}
			else
			{
				myXPLDevices[validPorts]->readBuffer[0] = '\0';
				switch (myXPLDevices[validPorts]->deviceType)
				{

				case XPLTYPE_XPLDIRECT:
					fprintf(errlog, "   Device on %s identifies as an XPLDIRECT device named: %s\n", myXPLDevices[validPorts]->port->portName, myXPLDevices[validPorts]->deviceName);
					break;

				case XPLTYPE_XPLWIZARD:
					fprintf(errlog, "   Device on %s identifies as an XPLWIZARD device named: %s\n", myXPLDevices[validPorts]->port->portName, myXPLDevices[validPorts]->deviceName);
					break;

				default:
					fprintf(errlog, "   Device on %s reports type: %i.  Type unknown.\n", myXPLDevices[validPorts]->port->portName, myXPLDevices[validPorts]->deviceType);

				}
				XPLMDebugString("*");


				//_writePacket(myXPLDevices[validPorts].Port, XPLCMD_RESET, "");

				//_writePacket(myXPLDevices[validPorts].Port, XPLCMD_SENDREQUEST, "");
				//startTime = GetTickCount();
				//while (GetTickCount() - startTime < XPL_TIMEOUT && !myXPLDevices[validPorts].active)	_processSerial();

				validPorts++;
			}

		}
		else
		{
			//port->shutDown();
			delete port;
		}
	}

	//delete myXPLDevices[validPorts];
	XPLMDebugString("  Done Searching Com Ports\n");
	fprintf(errlog, "Total of %i compatible devices were found.  \n\n", validPorts);
	return 0;

}

void _processSerial()
{
	int device = 0;

	while (myXPLDevices[device] && device <= validPorts)
	{
		//fprintf(errlog, "working on xpldevice %i ...", port);

		myXPLDevices[device]->processSerial();

		device++;
	}
}

/*
	 sendRefreshRequest -- request writable datarefs be refreshed
*/

void sendRefreshRequest(void)
{
	for (int i = 0; i < validPorts; i++)
	{
		if (myXPLDevices[i])
			if (myXPLDevices[i] && myXPLDevices[i]->RefsLoaded)  myXPLDevices[i]->_writePacket(XPLREQUEST_REFRESH, "");
	}

}

void sendExitMessage(void)
{
	fprintf(errlog, "\n Xplane indicates that it is closing or unloading the current aircraft.  I am letting all %i device(s) know.\n", validPorts);

	for (int i = 0; i < validPorts; i++)
	{
		if (myXPLDevices[i] && myXPLDevices[i]->RefsLoaded)  myXPLDevices[i]->_writePacket(XPL_EXITING, "");
	}

}



/*
*   reloadDevices
*/
void reloadDevices(void)
{
	fprintf(errlog, "XPLDirect device requested to reset and reload devices.  \n");


	disengageDevices();				// just to make sure we are cleared
	engageDevices();



}
